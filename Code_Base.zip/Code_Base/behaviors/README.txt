README for python wrapper

3 classes of functions in this wrapper:

- C++ utility functions

- C++ PyObject functions

- Python functions in python file


List of functions:

C++ utility:

- vector<tuple<VecPosition, int > > NaoBehavior::teamPositions(int _playerNumber);
- vector<tuple<VecPosition, int > > NaoBehavior::opponentPositions();
The above were defined in naobehaviour.h, declared in strategy.cc

