
import Robocup as RC

def selectSkill(world_data):
    RC.Robocup(world_data)
    #print("Python works")
    #print("My number is:",num)

    return 2