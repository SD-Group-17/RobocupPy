import Robocup

print(Robocup.first())